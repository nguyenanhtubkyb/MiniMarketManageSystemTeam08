﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MiniMarket_ManageApplication
{
    public partial class ProductForm : Form
    {
        DBConnect dBCon = new DBConnect();

        public ProductForm()
        {
            InitializeComponent();
        }

        private void Btn_Category_Click(object sender, EventArgs e)
        {
            CategoryForm category = new CategoryForm();
            category.Show();
            this.Hide();
        }

        private void ProductForm_Load(object sender, EventArgs e)
        {
            getCategory();
            getTable();
        }

        private void getCategory()
        {
            string selectQuerry = "SELECT * FROM Category";
            SqlCommand command = new SqlCommand(selectQuerry, dBCon.GetCon());
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            ComB_Category.DataSource = table;
            ComB_Category.ValueMember = "CatName";
            comB_Search.DataSource = table;
            comB_Search.ValueMember = "CatName";
        }

        private void getTable()
        {
            string selectQuerry = "SELECT * FROM Product";
            SqlCommand command = new SqlCommand(selectQuerry, dBCon.GetCon());
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            guna2DataGridView_Product.DataSource = table;
        }

        private void Clear()
        {
            TxtB_ID.Clear();
            TxtB_Name.Clear();
            TxtB_Price.Clear();
            TxtB_Quantity.Clear();
            ComB_Category.SelectedIndex = 0;
        }

        private void Btn_Add_Click(object sender, EventArgs e)
        {
            try
            {
                string insertQuery = "INSERT INTO Product VALUES(" + TxtB_ID.Text + ",'" + TxtB_Name.Text + "'," + TxtB_Price.Text + "," + TxtB_Quantity.Text + ",'" + ComB_Category.Text + "')";
                SqlCommand command = new SqlCommand(insertQuery, dBCon.GetCon());
                dBCon.OpenCon();
                command.ExecuteNonQuery();
                MessageBox.Show("Product Added Successfully", "Add Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dBCon.CloseCon();
                getTable();
                Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_Update_Click(object sender, EventArgs e)
        {
            try
            {
                if (TxtB_ID.Text == "" || TxtB_Name.Text == "" || TxtB_Price.Text == "" || TxtB_Quantity.Text == "")
                {
                    MessageBox.Show("Missing Information", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string updateQuery = "UPDATE Product SET ProdName='" + TxtB_Name.Text + "',ProdPrice=" + TxtB_Price.Text + ",ProdQty=" + TxtB_Quantity.Text + ",ProdCat='" + ComB_Category.Text + "'WHERE ProdId=" + TxtB_ID.Text + "";
                    SqlCommand command = new SqlCommand(updateQuery, dBCon.GetCon());
                    dBCon.OpenCon();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Product Updated Successfully", "Updated Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dBCon.CloseCon();
                    getTable();
                    Clear();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void guna2DataGridView_Product_Click(object sender, EventArgs e)
        {
            TxtB_ID.Text = guna2DataGridView_Product.SelectedRows[0].Cells[0].Value.ToString();
            TxtB_Name.Text = guna2DataGridView_Product.SelectedRows[0].Cells[1].Value.ToString();
            TxtB_Price.Text = guna2DataGridView_Product.SelectedRows[0].Cells[2].Value.ToString();
            TxtB_Quantity.Text = guna2DataGridView_Product.SelectedRows[0].Cells[3].Value.ToString();
            ComB_Category.SelectedValue = guna2DataGridView_Product.SelectedRows[0].Cells[4].Value.ToString();

        }

        private void Btn_Delete_Click(object sender, EventArgs e)
        {
            try
            {
                if (TxtB_ID.Text == "")
                {
                    MessageBox.Show("Missing Information", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                else
                {
                    string deleteQuery = "DELETE FROM Product WHERE ProdId=" + TxtB_ID.Text + "";
                    SqlCommand command = new SqlCommand(deleteQuery, dBCon.GetCon());
                    dBCon.OpenCon();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Product Deleted Successfully", "Deleted Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dBCon.CloseCon();
                    getTable();
                    Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btn_Refresh_Click(object sender, EventArgs e)
        {
            getTable();
        }

        private void comB_Search_SelectionChangeCommitted(object sender, EventArgs e)
        {
            string selectQuerry = "SELECT * FROM Product WHERE ProdCat='"+comB_Search.SelectedValue.ToString()+"'";
            SqlCommand command = new SqlCommand(selectQuerry, dBCon.GetCon());
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            guna2DataGridView_Product.DataSource = table;
        }

        private void Txt_Exit_MouseEnter(object sender, EventArgs e)
        {
            Txt_Exit.ForeColor = Color.Red;
        }

        private void Txt_Exit_MouseLeave(object sender, EventArgs e)
        {
            Txt_Exit.ForeColor = Color.RoyalBlue;
        }

        private void Txt_LogOut_MouseEnter(object sender, EventArgs e)
        {
            Txt_LogOut.ForeColor = Color.Red;
        }

        private void Txt_LogOut_MouseLeave(object sender, EventArgs e)
        {
            Txt_LogOut.ForeColor = Color.RoyalBlue;
        }

        private void Txt_LogOut_Click(object sender, EventArgs e)
        {
            LoginForm login = new LoginForm();
            login.Show();
            this.Hide();
        }

        private void Txt_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Btn_Seller_Click(object sender, EventArgs e)
        {
            SellerForm sellerForm = new SellerForm();
            sellerForm.Show();
            this.Hide();
        }

        private void Btn_Selling_Click(object sender, EventArgs e)
        {

        }
    }
}
