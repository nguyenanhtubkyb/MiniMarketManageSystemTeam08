﻿
namespace MiniMarket_ManageApplication
{
    partial class ProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button Btn_Add;
            System.Windows.Forms.Button Btn_Update;
            System.Windows.Forms.Button Btn_Delete;
            System.Windows.Forms.Button Btn_Refresh;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Panel = new System.Windows.Forms.Panel();
            this.guna2DataGridView_Product = new Guna.UI2.WinForms.Guna2DataGridView();
            this.Txt_Title = new System.Windows.Forms.Label();
            this.comB_Search = new System.Windows.Forms.ComboBox();
            this.ComB_Category = new System.Windows.Forms.ComboBox();
            this.Txt_Category = new System.Windows.Forms.Label();
            this.TxtB_Quantity = new Guna.UI2.WinForms.Guna2TextBox();
            this.Txt_Quantity = new System.Windows.Forms.Label();
            this.TxtB_Price = new Guna.UI2.WinForms.Guna2TextBox();
            this.Txt_Price = new System.Windows.Forms.Label();
            this.TxtB_Name = new Guna.UI2.WinForms.Guna2TextBox();
            this.Txt_Name = new System.Windows.Forms.Label();
            this.TxtB_ID = new Guna.UI2.WinForms.Guna2TextBox();
            this.Txt_ID = new System.Windows.Forms.Label();
            this.Txt_Exit = new System.Windows.Forms.Label();
            this.Btn_Seller = new System.Windows.Forms.Label();
            this.Btn_Category = new System.Windows.Forms.Label();
            this.Txt_LogOut = new System.Windows.Forms.Label();
            Btn_Add = new System.Windows.Forms.Button();
            Btn_Update = new System.Windows.Forms.Button();
            Btn_Delete = new System.Windows.Forms.Button();
            Btn_Refresh = new System.Windows.Forms.Button();
            this.Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView_Product)).BeginInit();
            this.SuspendLayout();
            // 
            // Btn_Add
            // 
            Btn_Add.FlatAppearance.BorderSize = 0;
            Btn_Add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            Btn_Add.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            Btn_Add.ForeColor = System.Drawing.Color.White;
            Btn_Add.Location = new System.Drawing.Point(15, 415);
            Btn_Add.Name = "Btn_Add";
            Btn_Add.Size = new System.Drawing.Size(102, 38);
            Btn_Add.TabIndex = 10;
            Btn_Add.Text = "Add";
            Btn_Add.UseVisualStyleBackColor = true;
            Btn_Add.Click += new System.EventHandler(this.Btn_Add_Click);
            // 
            // Btn_Update
            // 
            Btn_Update.FlatAppearance.BorderSize = 0;
            Btn_Update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            Btn_Update.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            Btn_Update.ForeColor = System.Drawing.Color.White;
            Btn_Update.Location = new System.Drawing.Point(123, 415);
            Btn_Update.Name = "Btn_Update";
            Btn_Update.Size = new System.Drawing.Size(121, 38);
            Btn_Update.TabIndex = 11;
            Btn_Update.Text = "Update";
            Btn_Update.UseVisualStyleBackColor = true;
            Btn_Update.Click += new System.EventHandler(this.Btn_Update_Click);
            // 
            // Btn_Delete
            // 
            Btn_Delete.FlatAppearance.BorderSize = 0;
            Btn_Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            Btn_Delete.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            Btn_Delete.ForeColor = System.Drawing.Color.White;
            Btn_Delete.Location = new System.Drawing.Point(262, 415);
            Btn_Delete.Name = "Btn_Delete";
            Btn_Delete.Size = new System.Drawing.Size(102, 38);
            Btn_Delete.TabIndex = 12;
            Btn_Delete.Text = "Delete";
            Btn_Delete.UseVisualStyleBackColor = true;
            Btn_Delete.Click += new System.EventHandler(this.Btn_Delete_Click);
            // 
            // Btn_Refresh
            // 
            Btn_Refresh.FlatAppearance.BorderSize = 0;
            Btn_Refresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            Btn_Refresh.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            Btn_Refresh.ForeColor = System.Drawing.Color.White;
            Btn_Refresh.Location = new System.Drawing.Point(697, 53);
            Btn_Refresh.Name = "Btn_Refresh";
            Btn_Refresh.Size = new System.Drawing.Size(102, 38);
            Btn_Refresh.TabIndex = 13;
            Btn_Refresh.Text = "Refresh";
            Btn_Refresh.UseVisualStyleBackColor = true;
            Btn_Refresh.Click += new System.EventHandler(this.Btn_Refresh_Click);
            // 
            // Panel
            // 
            this.Panel.BackColor = System.Drawing.Color.RoyalBlue;
            this.Panel.Controls.Add(this.guna2DataGridView_Product);
            this.Panel.Controls.Add(this.Txt_Title);
            this.Panel.Controls.Add(this.comB_Search);
            this.Panel.Controls.Add(Btn_Refresh);
            this.Panel.Controls.Add(Btn_Delete);
            this.Panel.Controls.Add(Btn_Update);
            this.Panel.Controls.Add(Btn_Add);
            this.Panel.Controls.Add(this.ComB_Category);
            this.Panel.Controls.Add(this.Txt_Category);
            this.Panel.Controls.Add(this.TxtB_Quantity);
            this.Panel.Controls.Add(this.Txt_Quantity);
            this.Panel.Controls.Add(this.TxtB_Price);
            this.Panel.Controls.Add(this.Txt_Price);
            this.Panel.Controls.Add(this.TxtB_Name);
            this.Panel.Controls.Add(this.Txt_Name);
            this.Panel.Controls.Add(this.TxtB_ID);
            this.Panel.Controls.Add(this.Txt_ID);
            this.Panel.Location = new System.Drawing.Point(163, 28);
            this.Panel.Name = "Panel";
            this.Panel.Size = new System.Drawing.Size(925, 610);
            this.Panel.TabIndex = 0;
            // 
            // guna2DataGridView_Product
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_Product.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.guna2DataGridView_Product.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView_Product.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.guna2DataGridView_Product.ColumnHeadersHeight = 24;
            this.guna2DataGridView_Product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView_Product.DefaultCellStyle = dataGridViewCellStyle3;
            this.guna2DataGridView_Product.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_Product.Location = new System.Drawing.Point(362, 104);
            this.guna2DataGridView_Product.Name = "guna2DataGridView_Product";
            this.guna2DataGridView_Product.RowHeadersVisible = false;
            this.guna2DataGridView_Product.RowHeadersWidth = 51;
            this.guna2DataGridView_Product.RowTemplate.Height = 24;
            this.guna2DataGridView_Product.Size = new System.Drawing.Size(552, 495);
            this.guna2DataGridView_Product.TabIndex = 16;
            this.guna2DataGridView_Product.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_Product.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView_Product.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView_Product.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView_Product.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView_Product.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_Product.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_Product.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_Product.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView_Product.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DataGridView_Product.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.guna2DataGridView_Product.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView_Product.ThemeStyle.HeaderStyle.Height = 24;
            this.guna2DataGridView_Product.ThemeStyle.ReadOnly = false;
            this.guna2DataGridView_Product.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_Product.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView_Product.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DataGridView_Product.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView_Product.ThemeStyle.RowsStyle.Height = 24;
            this.guna2DataGridView_Product.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_Product.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView_Product.Click += new System.EventHandler(this.guna2DataGridView_Product_Click);
            // 
            // Txt_Title
            // 
            this.Txt_Title.AutoSize = true;
            this.Txt_Title.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_Title.ForeColor = System.Drawing.Color.White;
            this.Txt_Title.Location = new System.Drawing.Point(312, 0);
            this.Txt_Title.Name = "Txt_Title";
            this.Txt_Title.Size = new System.Drawing.Size(295, 38);
            this.Txt_Title.TabIndex = 15;
            this.Txt_Title.Text = "MANAGE PRODUCTS";
            // 
            // comB_Search
            // 
            this.comB_Search.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comB_Search.FormattingEnabled = true;
            this.comB_Search.Location = new System.Drawing.Point(473, 60);
            this.comB_Search.Name = "comB_Search";
            this.comB_Search.Size = new System.Drawing.Size(204, 25);
            this.comB_Search.TabIndex = 14;
            this.comB_Search.Text = "Select Category";
            this.comB_Search.SelectionChangeCommitted += new System.EventHandler(this.comB_Search_SelectionChangeCommitted);
            // 
            // ComB_Category
            // 
            this.ComB_Category.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComB_Category.FormattingEnabled = true;
            this.ComB_Category.Location = new System.Drawing.Point(143, 342);
            this.ComB_Category.Name = "ComB_Category";
            this.ComB_Category.Size = new System.Drawing.Size(204, 25);
            this.ComB_Category.TabIndex = 9;
            this.ComB_Category.Text = "Select Category";
            // 
            // Txt_Category
            // 
            this.Txt_Category.AutoSize = true;
            this.Txt_Category.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_Category.ForeColor = System.Drawing.Color.White;
            this.Txt_Category.Location = new System.Drawing.Point(39, 336);
            this.Txt_Category.Name = "Txt_Category";
            this.Txt_Category.Size = new System.Drawing.Size(98, 28);
            this.Txt_Category.TabIndex = 8;
            this.Txt_Category.Text = "Category";
            // 
            // TxtB_Quantity
            // 
            this.TxtB_Quantity.BorderRadius = 18;
            this.TxtB_Quantity.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtB_Quantity.DefaultText = "";
            this.TxtB_Quantity.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TxtB_Quantity.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TxtB_Quantity.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TxtB_Quantity.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TxtB_Quantity.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TxtB_Quantity.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtB_Quantity.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TxtB_Quantity.Location = new System.Drawing.Point(141, 257);
            this.TxtB_Quantity.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtB_Quantity.Name = "TxtB_Quantity";
            this.TxtB_Quantity.PasswordChar = '\0';
            this.TxtB_Quantity.PlaceholderText = "";
            this.TxtB_Quantity.SelectedText = "";
            this.TxtB_Quantity.Size = new System.Drawing.Size(203, 43);
            this.TxtB_Quantity.TabIndex = 7;
            // 
            // Txt_Quantity
            // 
            this.Txt_Quantity.AutoSize = true;
            this.Txt_Quantity.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_Quantity.ForeColor = System.Drawing.Color.White;
            this.Txt_Quantity.Location = new System.Drawing.Point(38, 264);
            this.Txt_Quantity.Name = "Txt_Quantity";
            this.Txt_Quantity.Size = new System.Drawing.Size(95, 28);
            this.Txt_Quantity.TabIndex = 6;
            this.Txt_Quantity.Text = "Quantity";
            // 
            // TxtB_Price
            // 
            this.TxtB_Price.BorderRadius = 18;
            this.TxtB_Price.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtB_Price.DefaultText = "";
            this.TxtB_Price.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TxtB_Price.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TxtB_Price.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TxtB_Price.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TxtB_Price.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TxtB_Price.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtB_Price.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TxtB_Price.Location = new System.Drawing.Point(141, 206);
            this.TxtB_Price.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtB_Price.Name = "TxtB_Price";
            this.TxtB_Price.PasswordChar = '\0';
            this.TxtB_Price.PlaceholderText = "";
            this.TxtB_Price.SelectedText = "";
            this.TxtB_Price.Size = new System.Drawing.Size(203, 43);
            this.TxtB_Price.TabIndex = 5;
            // 
            // Txt_Price
            // 
            this.Txt_Price.AutoSize = true;
            this.Txt_Price.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_Price.ForeColor = System.Drawing.Color.White;
            this.Txt_Price.Location = new System.Drawing.Point(38, 213);
            this.Txt_Price.Name = "Txt_Price";
            this.Txt_Price.Size = new System.Drawing.Size(59, 28);
            this.Txt_Price.TabIndex = 4;
            this.Txt_Price.Text = "Price";
            // 
            // TxtB_Name
            // 
            this.TxtB_Name.BorderRadius = 18;
            this.TxtB_Name.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtB_Name.DefaultText = "";
            this.TxtB_Name.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TxtB_Name.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TxtB_Name.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TxtB_Name.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TxtB_Name.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TxtB_Name.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtB_Name.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TxtB_Name.Location = new System.Drawing.Point(142, 155);
            this.TxtB_Name.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtB_Name.Name = "TxtB_Name";
            this.TxtB_Name.PasswordChar = '\0';
            this.TxtB_Name.PlaceholderText = "";
            this.TxtB_Name.SelectedText = "";
            this.TxtB_Name.Size = new System.Drawing.Size(203, 43);
            this.TxtB_Name.TabIndex = 3;
            // 
            // Txt_Name
            // 
            this.Txt_Name.AutoSize = true;
            this.Txt_Name.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_Name.ForeColor = System.Drawing.Color.White;
            this.Txt_Name.Location = new System.Drawing.Point(39, 162);
            this.Txt_Name.Name = "Txt_Name";
            this.Txt_Name.Size = new System.Drawing.Size(68, 28);
            this.Txt_Name.TabIndex = 2;
            this.Txt_Name.Text = "Name";
            // 
            // TxtB_ID
            // 
            this.TxtB_ID.BorderRadius = 18;
            this.TxtB_ID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtB_ID.DefaultText = "";
            this.TxtB_ID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TxtB_ID.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TxtB_ID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TxtB_ID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TxtB_ID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TxtB_ID.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtB_ID.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TxtB_ID.Location = new System.Drawing.Point(143, 104);
            this.TxtB_ID.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtB_ID.Name = "TxtB_ID";
            this.TxtB_ID.PasswordChar = '\0';
            this.TxtB_ID.PlaceholderText = "";
            this.TxtB_ID.SelectedText = "";
            this.TxtB_ID.Size = new System.Drawing.Size(203, 43);
            this.TxtB_ID.TabIndex = 1;
            // 
            // Txt_ID
            // 
            this.Txt_ID.AutoSize = true;
            this.Txt_ID.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_ID.ForeColor = System.Drawing.Color.White;
            this.Txt_ID.Location = new System.Drawing.Point(40, 111);
            this.Txt_ID.Name = "Txt_ID";
            this.Txt_ID.Size = new System.Drawing.Size(33, 28);
            this.Txt_ID.TabIndex = 0;
            this.Txt_ID.Text = "ID";
            // 
            // Txt_Exit
            // 
            this.Txt_Exit.AutoSize = true;
            this.Txt_Exit.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_Exit.ForeColor = System.Drawing.Color.RoyalBlue;
            this.Txt_Exit.Location = new System.Drawing.Point(1075, -3);
            this.Txt_Exit.Name = "Txt_Exit";
            this.Txt_Exit.Size = new System.Drawing.Size(25, 28);
            this.Txt_Exit.TabIndex = 9;
            this.Txt_Exit.Text = "X";
            this.Txt_Exit.Click += new System.EventHandler(this.Txt_Exit_Click);
            this.Txt_Exit.MouseEnter += new System.EventHandler(this.Txt_Exit_MouseEnter);
            this.Txt_Exit.MouseLeave += new System.EventHandler(this.Txt_Exit_MouseLeave);
            // 
            // Btn_Seller
            // 
            this.Btn_Seller.AutoSize = true;
            this.Btn_Seller.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Seller.ForeColor = System.Drawing.Color.RoyalBlue;
            this.Btn_Seller.Location = new System.Drawing.Point(48, 132);
            this.Btn_Seller.Name = "Btn_Seller";
            this.Btn_Seller.Size = new System.Drawing.Size(65, 28);
            this.Btn_Seller.TabIndex = 10;
            this.Btn_Seller.Text = "Seller";
            this.Btn_Seller.Click += new System.EventHandler(this.Btn_Seller_Click);
            // 
            // Btn_Category
            // 
            this.Btn_Category.AutoSize = true;
            this.Btn_Category.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Category.ForeColor = System.Drawing.Color.RoyalBlue;
            this.Btn_Category.Location = new System.Drawing.Point(31, 198);
            this.Btn_Category.Name = "Btn_Category";
            this.Btn_Category.Size = new System.Drawing.Size(98, 28);
            this.Btn_Category.TabIndex = 11;
            this.Btn_Category.Text = "Category";
            this.Btn_Category.Click += new System.EventHandler(this.Btn_Category_Click);
            // 
            // Txt_LogOut
            // 
            this.Txt_LogOut.AutoSize = true;
            this.Txt_LogOut.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_LogOut.ForeColor = System.Drawing.Color.RoyalBlue;
            this.Txt_LogOut.Location = new System.Drawing.Point(37, 599);
            this.Txt_LogOut.Name = "Txt_LogOut";
            this.Txt_LogOut.Size = new System.Drawing.Size(81, 28);
            this.Txt_LogOut.TabIndex = 20;
            this.Txt_LogOut.Text = "LogOut";
            this.Txt_LogOut.Click += new System.EventHandler(this.Txt_LogOut_Click);
            this.Txt_LogOut.MouseEnter += new System.EventHandler(this.Txt_LogOut_MouseEnter);
            this.Txt_LogOut.MouseLeave += new System.EventHandler(this.Txt_LogOut_MouseLeave);
            // 
            // ProductForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 650);
            this.Controls.Add(this.Txt_LogOut);
            this.Controls.Add(this.Btn_Category);
            this.Controls.Add(this.Btn_Seller);
            this.Controls.Add(this.Txt_Exit);
            this.Controls.Add(this.Panel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ProductForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ProductForm";
            this.Load += new System.EventHandler(this.ProductForm_Load);
            this.Panel.ResumeLayout(false);
            this.Panel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView_Product)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel Panel;
        protected System.Windows.Forms.Label Txt_Exit;
        private System.Windows.Forms.Label Txt_ID;
        private Guna.UI2.WinForms.Guna2TextBox TxtB_ID;
        private System.Windows.Forms.Label Txt_Name;
        private Guna.UI2.WinForms.Guna2TextBox TxtB_Name;
        private Guna.UI2.WinForms.Guna2TextBox TxtB_Price;
        private System.Windows.Forms.Label Txt_Price;
        private Guna.UI2.WinForms.Guna2TextBox TxtB_Quantity;
        private System.Windows.Forms.Label Txt_Quantity;
        private System.Windows.Forms.Label Txt_Category;
        private System.Windows.Forms.ComboBox ComB_Category;
        private System.Windows.Forms.Label Txt_Title;
        private System.Windows.Forms.ComboBox comB_Search;
        private System.Windows.Forms.Label Btn_Seller;
        private System.Windows.Forms.Label Btn_Category;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView_Product;
        protected System.Windows.Forms.Label Txt_LogOut;
    }
}