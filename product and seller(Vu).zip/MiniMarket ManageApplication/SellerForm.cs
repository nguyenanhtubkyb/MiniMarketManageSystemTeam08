﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MiniMarket_ManageApplication
{
    public partial class SellerForm : Form
    {
        DBConnect dBCon = new DBConnect();
        public SellerForm()
        {
            InitializeComponent();
        }

        private void getTable()
        {
            string selectQuerry = "SELECT * FROM Seller";
            SqlCommand command = new SqlCommand(selectQuerry, dBCon.GetCon());
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable table = new DataTable();
            adapter.Fill(table);
            guna2DataGridView_Seller.DataSource = table;
        }

        private void Clear()
        {
            TxtB_ID.Clear();
            TxtB_Name.Clear();
            TxtB_Age.Clear();
            TxtB_Phone.Clear();
            TxtB_Password.Clear();
        }

        private void Btn_Add_Click(object sender, EventArgs e)
        {
            try
            {
                string insertQuery = "INSERT INTO Seller VALUES(" + TxtB_ID.Text + ",'" + TxtB_Name.Text + "','" + TxtB_Age.Text + "','" + TxtB_Phone.Text + "','" + TxtB_Password.Text + "')";
                SqlCommand command = new SqlCommand(insertQuery, dBCon.GetCon());
                dBCon.OpenCon();
                command.ExecuteNonQuery();
                MessageBox.Show("Seller Added Successfully", "Add Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                dBCon.CloseCon();
                getTable();
                Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SellerForm_Load(object sender, EventArgs e)
        {
            getTable();
        }

        private void Btn_Update_Click(object sender, EventArgs e)
        {
            try
            {
                if (TxtB_ID.Text == "" || TxtB_Name.Text == "" || TxtB_Age.Text == "" || TxtB_Phone.Text == "" || TxtB_Password.Text == "")
                {
                    MessageBox.Show("Missing Information", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string updateQuery = "UPDATE Seller SET SellerName='" + TxtB_Name.Text + "',SellerAge='" + TxtB_Age.Text + "',SellerPhone='" + TxtB_Phone.Text + "',SellerPass='" + TxtB_Password.Text + "'WHERE SellerId=" + TxtB_ID.Text + "";
                    SqlCommand command = new SqlCommand(updateQuery, dBCon.GetCon());
                    dBCon.OpenCon();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Seller Updated Successfully", "Updated Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dBCon.CloseCon();
                    getTable();
                    Clear();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void guna2DataGridView_Seller_Click(object sender, EventArgs e)
        {
            TxtB_ID.Text = guna2DataGridView_Seller.SelectedRows[0].Cells[0].Value.ToString();
            TxtB_Name.Text = guna2DataGridView_Seller.SelectedRows[0].Cells[1].Value.ToString();
            TxtB_Age.Text = guna2DataGridView_Seller.SelectedRows[0].Cells[2].Value.ToString();
            TxtB_Phone.Text = guna2DataGridView_Seller.SelectedRows[0].Cells[3].Value.ToString();
            TxtB_Password.Text = guna2DataGridView_Seller.SelectedRows[0].Cells[4].Value.ToString();

        }

        private void Btn_Delete_Click(object sender, EventArgs e)
        {
            try
            {
                if (TxtB_ID.Text == "")
                {
                    MessageBox.Show("Missing Information", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                else
                {
                    if ((MessageBox.Show("Are you sure you want to delete this record?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes))
                    {
                        string deleteQuery = "DELETE FROM Seller WHERE SellerId=" + TxtB_ID.Text + "";
                        SqlCommand command = new SqlCommand(deleteQuery, dBCon.GetCon());
                        dBCon.OpenCon();
                        command.ExecuteNonQuery();
                        MessageBox.Show("Seller Deleted Successfully", "Deleted Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dBCon.CloseCon();
                        getTable();
                        Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Txt_LogOut_Click(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm();
            loginForm.Show();
            this.Hide();
        }

        private void Txt_LogOut_MouseEnter(object sender, EventArgs e)
        {
            Txt_LogOut.ForeColor = Color.Red;
        }

        private void Txt_LogOut_MouseLeave(object sender, EventArgs e)
        {
            Txt_LogOut.ForeColor = Color.RoyalBlue;
        }

        private void Txt_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Txt_Exit_MouseEnter(object sender, EventArgs e)
        {
            Txt_Exit.ForeColor = Color.Red;
        }

        private void Txt_Exit_MouseLeave(object sender, EventArgs e)
        {
            Txt_Exit.ForeColor = Color.RoyalBlue;
        }

        private void Btn_Product_Click(object sender, EventArgs e)
        {
            ProductForm productForm = new ProductForm();
            productForm.Show();
            this.Hide();
        }

        private void Btn_Category_Click(object sender, EventArgs e)
        {
            CategoryForm categoryForm = new CategoryForm();
            categoryForm.Show();
            this.Hide();
        }
    }
}
