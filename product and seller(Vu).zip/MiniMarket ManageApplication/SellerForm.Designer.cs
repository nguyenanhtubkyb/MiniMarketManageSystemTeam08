﻿
namespace MiniMarket_ManageApplication
{
    partial class SellerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Button Btn_Delete;
            System.Windows.Forms.Button Btn_Update;
            System.Windows.Forms.Button Btn_Add;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Txt_LogOut = new System.Windows.Forms.Label();
            this.Btn_Category = new System.Windows.Forms.Label();
            this.guna2DataGridView_Seller = new Guna.UI2.WinForms.Guna2DataGridView();
            this.Txt_Title = new System.Windows.Forms.Label();
            this.TxtB_Phone = new Guna.UI2.WinForms.Guna2TextBox();
            this.Btn_Product = new System.Windows.Forms.Label();
            this.Txt_Exit = new System.Windows.Forms.Label();
            this.Txt_Phone = new System.Windows.Forms.Label();
            this.TxtB_Age = new Guna.UI2.WinForms.Guna2TextBox();
            this.Txt_Age = new System.Windows.Forms.Label();
            this.Txt_Name = new System.Windows.Forms.Label();
            this.Txt_ID = new System.Windows.Forms.Label();
            this.Panel = new System.Windows.Forms.Panel();
            this.TxtB_Password = new Guna.UI2.WinForms.Guna2TextBox();
            this.Txt_PassWord = new System.Windows.Forms.Label();
            this.TxtB_Name = new Guna.UI2.WinForms.Guna2TextBox();
            this.TxtB_ID = new Guna.UI2.WinForms.Guna2TextBox();
            Btn_Delete = new System.Windows.Forms.Button();
            Btn_Update = new System.Windows.Forms.Button();
            Btn_Add = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView_Seller)).BeginInit();
            this.Panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Btn_Delete
            // 
            Btn_Delete.FlatAppearance.BorderSize = 0;
            Btn_Delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            Btn_Delete.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            Btn_Delete.ForeColor = System.Drawing.Color.White;
            Btn_Delete.Location = new System.Drawing.Point(259, 375);
            Btn_Delete.Name = "Btn_Delete";
            Btn_Delete.Size = new System.Drawing.Size(102, 38);
            Btn_Delete.TabIndex = 12;
            Btn_Delete.Text = "Delete";
            Btn_Delete.UseVisualStyleBackColor = true;
            Btn_Delete.Click += new System.EventHandler(this.Btn_Delete_Click);
            // 
            // Btn_Update
            // 
            Btn_Update.FlatAppearance.BorderSize = 0;
            Btn_Update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            Btn_Update.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            Btn_Update.ForeColor = System.Drawing.Color.White;
            Btn_Update.Location = new System.Drawing.Point(132, 375);
            Btn_Update.Name = "Btn_Update";
            Btn_Update.Size = new System.Drawing.Size(121, 38);
            Btn_Update.TabIndex = 11;
            Btn_Update.Text = "Update";
            Btn_Update.UseVisualStyleBackColor = true;
            Btn_Update.Click += new System.EventHandler(this.Btn_Update_Click);
            // 
            // Btn_Add
            // 
            Btn_Add.FlatAppearance.BorderSize = 0;
            Btn_Add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            Btn_Add.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            Btn_Add.ForeColor = System.Drawing.Color.White;
            Btn_Add.Location = new System.Drawing.Point(24, 375);
            Btn_Add.Name = "Btn_Add";
            Btn_Add.Size = new System.Drawing.Size(102, 38);
            Btn_Add.TabIndex = 10;
            Btn_Add.Text = "Add";
            Btn_Add.UseVisualStyleBackColor = true;
            Btn_Add.Click += new System.EventHandler(this.Btn_Add_Click);
            // 
            // Txt_LogOut
            // 
            this.Txt_LogOut.AutoSize = true;
            this.Txt_LogOut.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_LogOut.ForeColor = System.Drawing.Color.RoyalBlue;
            this.Txt_LogOut.Location = new System.Drawing.Point(28, 607);
            this.Txt_LogOut.Name = "Txt_LogOut";
            this.Txt_LogOut.Size = new System.Drawing.Size(81, 28);
            this.Txt_LogOut.TabIndex = 26;
            this.Txt_LogOut.Text = "LogOut";
            this.Txt_LogOut.Click += new System.EventHandler(this.Txt_LogOut_Click);
            this.Txt_LogOut.MouseEnter += new System.EventHandler(this.Txt_LogOut_MouseEnter);
            this.Txt_LogOut.MouseLeave += new System.EventHandler(this.Txt_LogOut_MouseLeave);
            // 
            // Btn_Category
            // 
            this.Btn_Category.AutoSize = true;
            this.Btn_Category.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Category.ForeColor = System.Drawing.Color.RoyalBlue;
            this.Btn_Category.Location = new System.Drawing.Point(22, 206);
            this.Btn_Category.Name = "Btn_Category";
            this.Btn_Category.Size = new System.Drawing.Size(98, 28);
            this.Btn_Category.TabIndex = 24;
            this.Btn_Category.Text = "Category";
            this.Btn_Category.Click += new System.EventHandler(this.Btn_Category_Click);
            // 
            // guna2DataGridView_Seller
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_Seller.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.guna2DataGridView_Seller.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.guna2DataGridView_Seller.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.guna2DataGridView_Seller.ColumnHeadersHeight = 24;
            this.guna2DataGridView_Seller.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.guna2DataGridView_Seller.DefaultCellStyle = dataGridViewCellStyle3;
            this.guna2DataGridView_Seller.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_Seller.Location = new System.Drawing.Point(370, 104);
            this.guna2DataGridView_Seller.Name = "guna2DataGridView_Seller";
            this.guna2DataGridView_Seller.RowHeadersVisible = false;
            this.guna2DataGridView_Seller.RowHeadersWidth = 51;
            this.guna2DataGridView_Seller.RowTemplate.Height = 24;
            this.guna2DataGridView_Seller.Size = new System.Drawing.Size(558, 488);
            this.guna2DataGridView_Seller.TabIndex = 16;
            this.guna2DataGridView_Seller.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_Seller.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.guna2DataGridView_Seller.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView_Seller.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.guna2DataGridView_Seller.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.guna2DataGridView_Seller.ThemeStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_Seller.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_Seller.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_Seller.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.guna2DataGridView_Seller.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DataGridView_Seller.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.guna2DataGridView_Seller.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.guna2DataGridView_Seller.ThemeStyle.HeaderStyle.Height = 24;
            this.guna2DataGridView_Seller.ThemeStyle.ReadOnly = false;
            this.guna2DataGridView_Seller.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.guna2DataGridView_Seller.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.guna2DataGridView_Seller.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2DataGridView_Seller.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView_Seller.ThemeStyle.RowsStyle.Height = 24;
            this.guna2DataGridView_Seller.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(229)))), ((int)(((byte)(255)))));
            this.guna2DataGridView_Seller.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(71)))), ((int)(((byte)(69)))), ((int)(((byte)(94)))));
            this.guna2DataGridView_Seller.Click += new System.EventHandler(this.guna2DataGridView_Seller_Click);
            // 
            // Txt_Title
            // 
            this.Txt_Title.AutoSize = true;
            this.Txt_Title.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_Title.ForeColor = System.Drawing.Color.White;
            this.Txt_Title.Location = new System.Drawing.Point(312, 0);
            this.Txt_Title.Name = "Txt_Title";
            this.Txt_Title.Size = new System.Drawing.Size(241, 38);
            this.Txt_Title.TabIndex = 15;
            this.Txt_Title.Text = "MANAGE SELLER";
            // 
            // TxtB_Phone
            // 
            this.TxtB_Phone.BorderRadius = 18;
            this.TxtB_Phone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtB_Phone.DefaultText = "";
            this.TxtB_Phone.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TxtB_Phone.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TxtB_Phone.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TxtB_Phone.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TxtB_Phone.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TxtB_Phone.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtB_Phone.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TxtB_Phone.Location = new System.Drawing.Point(142, 257);
            this.TxtB_Phone.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtB_Phone.Name = "TxtB_Phone";
            this.TxtB_Phone.PasswordChar = '\0';
            this.TxtB_Phone.PlaceholderText = "";
            this.TxtB_Phone.SelectedText = "";
            this.TxtB_Phone.Size = new System.Drawing.Size(203, 43);
            this.TxtB_Phone.TabIndex = 7;
            // 
            // Btn_Product
            // 
            this.Btn_Product.AutoSize = true;
            this.Btn_Product.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_Product.ForeColor = System.Drawing.Color.RoyalBlue;
            this.Btn_Product.Location = new System.Drawing.Point(28, 140);
            this.Btn_Product.Name = "Btn_Product";
            this.Btn_Product.Size = new System.Drawing.Size(86, 28);
            this.Btn_Product.TabIndex = 23;
            this.Btn_Product.Text = "Product";
            this.Btn_Product.Click += new System.EventHandler(this.Btn_Product_Click);
            // 
            // Txt_Exit
            // 
            this.Txt_Exit.AutoSize = true;
            this.Txt_Exit.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_Exit.ForeColor = System.Drawing.Color.RoyalBlue;
            this.Txt_Exit.Location = new System.Drawing.Point(1060, 5);
            this.Txt_Exit.Name = "Txt_Exit";
            this.Txt_Exit.Size = new System.Drawing.Size(25, 28);
            this.Txt_Exit.TabIndex = 22;
            this.Txt_Exit.Text = "X";
            this.Txt_Exit.Click += new System.EventHandler(this.Txt_Exit_Click);
            this.Txt_Exit.MouseEnter += new System.EventHandler(this.Txt_Exit_MouseEnter);
            this.Txt_Exit.MouseLeave += new System.EventHandler(this.Txt_Exit_MouseLeave);
            // 
            // Txt_Phone
            // 
            this.Txt_Phone.AutoSize = true;
            this.Txt_Phone.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_Phone.ForeColor = System.Drawing.Color.White;
            this.Txt_Phone.Location = new System.Drawing.Point(19, 264);
            this.Txt_Phone.Name = "Txt_Phone";
            this.Txt_Phone.Size = new System.Drawing.Size(105, 28);
            this.Txt_Phone.TabIndex = 6;
            this.Txt_Phone.Text = "Phone No";
            // 
            // TxtB_Age
            // 
            this.TxtB_Age.BorderRadius = 18;
            this.TxtB_Age.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtB_Age.DefaultText = "";
            this.TxtB_Age.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TxtB_Age.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TxtB_Age.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TxtB_Age.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TxtB_Age.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TxtB_Age.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtB_Age.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TxtB_Age.Location = new System.Drawing.Point(142, 206);
            this.TxtB_Age.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtB_Age.Name = "TxtB_Age";
            this.TxtB_Age.PasswordChar = '\0';
            this.TxtB_Age.PlaceholderText = "";
            this.TxtB_Age.SelectedText = "";
            this.TxtB_Age.Size = new System.Drawing.Size(203, 43);
            this.TxtB_Age.TabIndex = 5;
            // 
            // Txt_Age
            // 
            this.Txt_Age.AutoSize = true;
            this.Txt_Age.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_Age.ForeColor = System.Drawing.Color.White;
            this.Txt_Age.Location = new System.Drawing.Point(19, 213);
            this.Txt_Age.Name = "Txt_Age";
            this.Txt_Age.Size = new System.Drawing.Size(49, 28);
            this.Txt_Age.TabIndex = 4;
            this.Txt_Age.Text = "Age";
            // 
            // Txt_Name
            // 
            this.Txt_Name.AutoSize = true;
            this.Txt_Name.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_Name.ForeColor = System.Drawing.Color.White;
            this.Txt_Name.Location = new System.Drawing.Point(19, 162);
            this.Txt_Name.Name = "Txt_Name";
            this.Txt_Name.Size = new System.Drawing.Size(68, 28);
            this.Txt_Name.TabIndex = 2;
            this.Txt_Name.Text = "Name";
            // 
            // Txt_ID
            // 
            this.Txt_ID.AutoSize = true;
            this.Txt_ID.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_ID.ForeColor = System.Drawing.Color.White;
            this.Txt_ID.Location = new System.Drawing.Point(19, 111);
            this.Txt_ID.Name = "Txt_ID";
            this.Txt_ID.Size = new System.Drawing.Size(33, 28);
            this.Txt_ID.TabIndex = 0;
            this.Txt_ID.Text = "ID";
            // 
            // Panel
            // 
            this.Panel.BackColor = System.Drawing.Color.RoyalBlue;
            this.Panel.Controls.Add(this.TxtB_Password);
            this.Panel.Controls.Add(this.Txt_PassWord);
            this.Panel.Controls.Add(this.guna2DataGridView_Seller);
            this.Panel.Controls.Add(this.Txt_Title);
            this.Panel.Controls.Add(Btn_Delete);
            this.Panel.Controls.Add(Btn_Update);
            this.Panel.Controls.Add(Btn_Add);
            this.Panel.Controls.Add(this.TxtB_Phone);
            this.Panel.Controls.Add(this.Txt_Phone);
            this.Panel.Controls.Add(this.TxtB_Age);
            this.Panel.Controls.Add(this.Txt_Age);
            this.Panel.Controls.Add(this.TxtB_Name);
            this.Panel.Controls.Add(this.Txt_Name);
            this.Panel.Controls.Add(this.TxtB_ID);
            this.Panel.Controls.Add(this.Txt_ID);
            this.Panel.Location = new System.Drawing.Point(148, 36);
            this.Panel.Name = "Panel";
            this.Panel.Size = new System.Drawing.Size(940, 602);
            this.Panel.TabIndex = 21;
            // 
            // TxtB_Password
            // 
            this.TxtB_Password.BorderRadius = 18;
            this.TxtB_Password.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtB_Password.DefaultText = "";
            this.TxtB_Password.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TxtB_Password.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TxtB_Password.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TxtB_Password.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TxtB_Password.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TxtB_Password.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtB_Password.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TxtB_Password.Location = new System.Drawing.Point(141, 308);
            this.TxtB_Password.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtB_Password.Name = "TxtB_Password";
            this.TxtB_Password.PasswordChar = '●';
            this.TxtB_Password.PlaceholderText = "";
            this.TxtB_Password.SelectedText = "";
            this.TxtB_Password.Size = new System.Drawing.Size(203, 43);
            this.TxtB_Password.TabIndex = 18;
            this.TxtB_Password.UseSystemPasswordChar = true;
            // 
            // Txt_PassWord
            // 
            this.Txt_PassWord.AutoSize = true;
            this.Txt_PassWord.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Txt_PassWord.ForeColor = System.Drawing.Color.White;
            this.Txt_PassWord.Location = new System.Drawing.Point(18, 315);
            this.Txt_PassWord.Name = "Txt_PassWord";
            this.Txt_PassWord.Size = new System.Drawing.Size(101, 28);
            this.Txt_PassWord.TabIndex = 17;
            this.Txt_PassWord.Text = "Password";
            // 
            // TxtB_Name
            // 
            this.TxtB_Name.BorderRadius = 18;
            this.TxtB_Name.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtB_Name.DefaultText = "";
            this.TxtB_Name.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TxtB_Name.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TxtB_Name.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TxtB_Name.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TxtB_Name.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TxtB_Name.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtB_Name.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TxtB_Name.Location = new System.Drawing.Point(142, 155);
            this.TxtB_Name.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtB_Name.Name = "TxtB_Name";
            this.TxtB_Name.PasswordChar = '\0';
            this.TxtB_Name.PlaceholderText = "";
            this.TxtB_Name.SelectedText = "";
            this.TxtB_Name.Size = new System.Drawing.Size(203, 43);
            this.TxtB_Name.TabIndex = 3;
            // 
            // TxtB_ID
            // 
            this.TxtB_ID.BorderRadius = 18;
            this.TxtB_ID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtB_ID.DefaultText = "";
            this.TxtB_ID.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.TxtB_ID.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.TxtB_ID.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TxtB_ID.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.TxtB_ID.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TxtB_ID.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TxtB_ID.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.TxtB_ID.Location = new System.Drawing.Point(142, 104);
            this.TxtB_ID.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.TxtB_ID.Name = "TxtB_ID";
            this.TxtB_ID.PasswordChar = '\0';
            this.TxtB_ID.PlaceholderText = "";
            this.TxtB_ID.SelectedText = "";
            this.TxtB_ID.Size = new System.Drawing.Size(203, 43);
            this.TxtB_ID.TabIndex = 1;
            // 
            // SellerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 650);
            this.Controls.Add(this.Txt_LogOut);
            this.Controls.Add(this.Btn_Category);
            this.Controls.Add(this.Btn_Product);
            this.Controls.Add(this.Txt_Exit);
            this.Controls.Add(this.Panel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SellerForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SellerForm";
            this.Load += new System.EventHandler(this.SellerForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.guna2DataGridView_Seller)).EndInit();
            this.Panel.ResumeLayout(false);
            this.Panel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        protected System.Windows.Forms.Label Txt_LogOut;
        private System.Windows.Forms.Label Btn_Category;
        private Guna.UI2.WinForms.Guna2DataGridView guna2DataGridView_Seller;
        private System.Windows.Forms.Label Txt_Title;
        private Guna.UI2.WinForms.Guna2TextBox TxtB_Phone;
        private System.Windows.Forms.Label Btn_Product;
        protected System.Windows.Forms.Label Txt_Exit;
        private System.Windows.Forms.Label Txt_Phone;
        private Guna.UI2.WinForms.Guna2TextBox TxtB_Age;
        private System.Windows.Forms.Label Txt_Age;
        private System.Windows.Forms.Label Txt_Name;
        private System.Windows.Forms.Label Txt_ID;
        private System.Windows.Forms.Panel Panel;
        private Guna.UI2.WinForms.Guna2TextBox TxtB_Name;
        private Guna.UI2.WinForms.Guna2TextBox TxtB_ID;
        private Guna.UI2.WinForms.Guna2TextBox TxtB_Password;
        private System.Windows.Forms.Label Txt_PassWord;
    }
}